
public class Start {
	public static void main(String[] args) {
		Student.TestStudent();
	}
}