fun main(args: Array<String>){
    Student.Companion.TestStudent()
}